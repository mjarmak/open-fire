# @jeniusapps/consent

Shared consent dialog and persistence for Jenius Apps, Open Order dashboard,
Open Fire and Open Remixer. Framework independent and safe to import during SSR.
Use `enabled: false` for server rendering and isolated demos.

The three choices are `denied` (essential storage only), `cookies` (optional
preferences, analytics off) and `granted` (preferences and analytics). No separate
optional preference cookies are currently added. Authentication is separate.
Choices use a per-app, host-only cookie and localStorage with a one-year expiry.
The logger's anonymous identifier uses localStorage only after analytics consent.

```ts
import { createConsentManager, mountConsentDialog } from '@jeniusapps/consent';
import { createOptionalLogger } from '@jeniusapps/analytics-client';
const manager = createConsentManager({document, appId: 'my-app', appName: 'My App', noticeVersion: 2});
const logger = createOptionalLogger({document, manager, slug: 'my-app'});
const unmount = mountConsentDialog(host, manager, {analyticsProvider: 'jenius', animate: false});
// On teardown: unmount(); logger.destroy(); manager.destroy();
```

Version 2 renews consent for Jenius Analytics. Existing v1 refusals and cookies-only
choices carry forward; a previous grant never enables the new provider. An app can
reopen the dialog with `manager.open()`. There is no floating settings control.
Open Remixer mounts after authentication, with entrance motion disabled.

The Jenius notice describes named button clicks, final HTTP 400–599 errors,
sanitized page/API URLs, anonymous IDs and 90-day retention. It excludes bodies,
headers, tokens, form/file contents, successful requests and replay. Provider
`none` discloses that analytics is disconnected. The legacy Google adapter remains
available for other consumers; migrated apps call `retireGoogleAnalytics` to set
Google's opt-out flag and clear its old cookies without loading a tag.

Source lives in `jeniusapps/packages/consent`. Bump the version, run
`npm run package:consent`, install the released archive in each consumer's
`vendor/` directory, then test/build and commit its package and lockfile. Consumers
use the same released library, not copied dialog code. No runtime CDN, sibling
checkout or registry login is needed. Never edit an archive in a consumer.
