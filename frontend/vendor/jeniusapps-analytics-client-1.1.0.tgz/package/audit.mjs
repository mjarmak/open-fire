/** Compile-time coverage audit. Reads authored templates, never visitor DOM text. */
import { readdir, readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { resolve, extname, basename } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';

export async function auditControls({root = 'src/app', project = process.cwd(), write = false} = {}) {
  const require = createRequire(resolve(project, 'package.json'));
  const ts = require('typescript');
  const {parseTemplate} = await import(pathToFileURL(require.resolve('@angular/compiler')).href);
  const files = [];
  async function scan(folder) {
    for (const entry of await readdir(folder, {withFileTypes:true})) {
      const path = resolve(folder,entry.name);
      if (entry.isDirectory()) await scan(path);
      else if (/\.(html|ts)$/.test(entry.name) && !/\.spec\.ts$/.test(entry.name)) files.push(path);
    }
  }
  await scan(resolve(project,root));
  const report = {templates:0, controls:0, missing:[], updated:[], errors:[]};
  function label(value) { return String(value).replace(/([a-z0-9])([A-Z])/g,'$1_$2').toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,''); }
  function short(value) { return value.length <= 64 ? value : value.slice(0,55)+'_'+createHash('sha256').update(value).digest('hex').slice(0,8); }
  for (const path of files.sort()) {
    const source = await readFile(path,'utf8');
    const templates = [];
    if (extname(path) === '.html') templates.push({text:source,offset:0});
    else {
      const tree = ts.createSourceFile(path,source,ts.ScriptTarget.Latest,true);
      function visit(node) {
        if (ts.isPropertyAssignment(node) && node.name.getText(tree) === 'template'
          && ts.isCallExpression(node.parent.parent) && node.parent.parent.expression.getText(tree) === 'Component') {
          const value = node.initializer;
          if (ts.isNoSubstitutionTemplateLiteral(value) || ts.isStringLiteral(value)) {
            templates.push({text:source.slice(value.getStart(tree)+1,value.end-1),offset:value.getStart(tree)+1});
          } else report.errors.push(`${path}: dynamic component template needs review`);
        }
        ts.forEachChild(node,visit);
      }
      visit(tree);
    }
    const edits=[];
    for (const template of templates) {
      report.templates++;
      const parsed = parseTemplate(template.text,path,{preserveWhitespaces:true});
      if (parsed.errors?.length) { report.errors.push(...parsed.errors.map(error=>String(error))); continue; }
      const scope = label(basename(path).replace(/(?:\.component)?\.(ts|html)$/,''));
      let ordinal=0;
      function walk(node) {
        if (!node || typeof node !== 'object') return;
        if (node.name && node.startSourceSpan && Array.isArray(node.attributes)) {
          const attrs = new Map(node.attributes.map(attr=>[attr.name,attr.value]));
          const bound = new Map((node.inputs??[]).map(input=>[input.name,input.value?.source??'']));
          const outputs = new Map((node.outputs??[]).map(event=>[event.name,event.handler?.source??'']));
          const tag=node.name.toLowerCase();
          const role=attrs.get('role');
          const sensitive = /password|token|secret|credential|api.?key/i.test([attrs.get('type'),attrs.get('formControlName'),attrs.get('name'),bound.get('type'),bound.get('ngModel'),bound.get('formControl')].join(' '));
          const isField = ['input','textarea','select','mat-select','mat-checkbox','mat-radio-button','mat-slide-toggle','mat-button-toggle'].includes(tag);
          const field = [...bound.values(),...outputs.values(),attrs.get('type'),attrs.get('placeholder'),attrs.get('title')].join(' ');
          const search = isField && /search|query/i.test(field);
          const channel = isField && !['button','submit','reset','hidden'].includes(attrs.get('type'))
            ? sensitive ? null : search ? 'input' : 'change' : null;
          const click = ['button','a','area','summary','mat-option','mat-tab','mat-menu-item','mat-select','mat-button-toggle','mat-slide-toggle'].includes(tag)
            || attrs.has('routerLink') || bound.has('routerLink')
            || attrs.has('appAuthenticatedDownload') || bound.has('appAuthenticatedDownload') || bound.has('matMenuTriggerFor')
            || ['button','link','tab','menuitem','menuitemcheckbox','menuitemradio','option','treeitem','checkbox','radio','switch','combobox','slider','spinbutton','gridcell'].includes(role)
            || (outputs.has('click') && !/^\s*\$event\.(stopPropagation|preventDefault)\(\)\s*;?\s*$/.test(outputs.get('click')))
            || ['button','submit','reset'].includes(attrs.get('type'));
          const press = !click && !isField && (outputs.has('pointerdown') || outputs.has('mousedown'));
          const channels=[...(click?['click']:[]),...(press?['press']:[]),...(channel?[channel]:[]),...(outputs.has('dblclick')?['doubleclick']:[]),...(outputs.has('contextmenu')?['context']:[])];
          let additions='';
          for (const event of channels) {
            ordinal++; report.controls++;
            const attribute=`data-analytics-${event}`;
            if (attrs.has(attribute)) {
              if (!/^[a-z][a-z0-9_.-]{0,63}$/.test(attrs.get(attribute))) report.errors.push(`${path}:${node.sourceSpan.start.line+1}: invalid static ${attribute}`);
              continue;
            }
            if (bound.has('attr.'+attribute) || bound.has(attribute)) { report.errors.push(`${path}: analytics names must be authored constants`); continue; }
            const handler = outputs.get(event==='doubleclick'?'dblclick':event==='context'?'contextmenu':event)??outputs.get('ngModelChange')??'';
            const method = handler.replace(/\$event\.[a-zA-Z]+\([^)]*\);?/g,'').match(/(?:this\.)?([a-zA-Z][a-zA-Z0-9]*)\s*(?:\?\.)?\(/)?.[1];
            const aria = attrs.get('aria-label');
            const action = aria && !aria.includes('{{') ? aria : method ?? attrs.get('formControlName') ?? attrs.get('name') ?? `${tag}_${ordinal}`;
            const name=short(`${scope}_${label(action)}${event==='click'?'':'_'+event}`);
            report.missing.push({path,line:node.sourceSpan.start.line+1,tag,event,name});
            additions+=` ${attribute}="${name}"`;
          }
          if (additions) {
            let offset=node.startSourceSpan.end.offset-1;
            if (template.text[offset-1]==='/') offset--;
            edits.push({offset:template.offset+offset,text:additions});
          }
        }
        for (const key of ['children','branches','cases']) if (Array.isArray(node[key])) node[key].forEach(walk);
        for (const key of ['empty','placeholder','loading','error']) if (node[key]) walk(node[key]);
      }
      parsed.nodes.forEach(walk);
    }
    if (write && edits.length && !report.errors.length) {
      let updated=source;
      for (const edit of edits.sort((a,b)=>b.offset-a.offset)) updated=updated.slice(0,edit.offset)+edit.text+updated.slice(edit.offset);
      await writeFile(path,updated);
      report.updated.push(path);
    }
  }
  return report;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args=process.argv.slice(2);
  const root=args.includes('--root')?args[args.indexOf('--root')+1]:'src/app';
  const report=await auditControls({root,write:args.includes('--write')});
  console.log(JSON.stringify(report,null,2));
  if (report.errors.length || (!args.includes('--write') && report.missing.length)) process.exitCode=1;
}
