export interface OptionalLogger {
  trackClick(name: string, url?: string): void;
  recordHttpError(error: {url: string; method?: string; status: number}): void;
  flush(): Promise<void>;
  destroy(): void;
}
export interface ConsentController {
  readonly enabled: boolean;
  subscribe(listener: (state: {readonly analytics: boolean}) => void): () => void;
}
export function createOptionalLogger(options?: {
  document?: Document; manager?: ConsentController; slug?: string; endpoint?: string;
  transport?: typeof fetch; storage?: Storage; platform?: 'web' | 'electron' | 'android'; flushMs?: number; captureLibraryControls?: boolean;
}): OptionalLogger;
export function createAnalytics(options: {endpoint: string; appId: number; writeKey: string; platform?: string; appVersion?: string; storage?: Storage; transport?: typeof fetch; flushMs?: number}): {
  setConsent(granted: boolean): void;
  track(name: string, fields?: {kind?: 'page'|'action'|'screen'|'api'|'error'; url?: string; apiUrl?: string; method?: string; status?: number; screen?: string; feature?: string}): void;
  flush(): Promise<void>; destroy(): void;
};
