# @jeniusapps/analytics-client

Optional framework independent logger, with no setup UI or startup dependency.

```ts
const logger = createOptionalLogger({document, manager, slug: 'open-order'});
// HTML: <button data-analytics-click="submit_order">Place order</button>
// Forward final HttpClient errors only:
logger.recordHttpError({url: request.urlWithParams, method: request.method, status: error.status});
```

Only after analytics consent, one best-effort public configuration request resolves
the slug to its numerical ID and public collection key. Missing configuration,
an offline collector or non-HTTPS page leaves logging off. The app never awaits
this request. Known apps register on server startup without changing existing
names, origins, keys or IDs. Additional apps can register in the admin dashboard.

Only explicit developer-authored interaction names and HTTP 400–599 errors are
collected. No rendered text, element IDs, request/response data or headers are read.
No global fetch patch, page tracking, successful requests or replay. Queries,
fragments and common private path identifiers are removed from page/API URLs.
Never put private strings in event names or route segments. API errors must come
from a registered app origin; authentication and analytics requests are excluded.

Withdrawal aborts configuration/collection, clears the queue and removes the
app's anonymous localStorage ID. Cookies-only and refusal never enable logging.
Already transmitted events expire through server retention. Batches contain up
to 20 events, queue up to 100, and retry temporary failures at most three times.

Consumers pin the release archive in `vendor/`. Repack and reinstall all consumers
after source changes. Current integrations cover web shells including PWA, TWA
and Electron hosts. Native Android/Kotlin requires a separate integration.

All authored buttons, links, role controls, pointer actions and non-credential
form controls in the four consumers are audited with Angular's template parser.
`npm run test:analytics-controls` fails when a new control lacks a fixed name;
run the same command with `-- --write` to generate names, then review them.
Never derive names from rendered text, values, attributes containing user data,
or loop items. Repeated rows intentionally share the same authored action name.

`data-analytics-click`, `data-analytics-change`, `data-analytics-input`,
`data-analytics-press`, `data-analytics-doubleclick` and `data-analytics-context`
cover clicks, committed changes, debounced search use, pointer actions, double
clicks and context menus. Search typing coalesces for 600 ms; no value is read.
Credential entry is excluded. Disabled/inert/aria-disabled controls are ignored.
With `captureLibraryControls: true`, generated calendar, datepicker, paginator
and tab controls use a fixed widget category without reading their labels or
selected values. Consent withdrawal also cancels pending search timers.
Remixer lazy-loads the logger after consent to preserve its initial bundle limit.
