/** Small optional event client. No collection or storage before setConsent(true). */
export function createAnalytics({ endpoint, appId, writeKey, platform = 'web', appVersion, storage, transport = globalThis.fetch?.bind(globalThis), makeId = () => globalThis.crypto.randomUUID(), clock = Date.now, flushMs = 5000 }) {
  const address = new URL(endpoint);
  if (address.protocol !== 'https:' && !['localhost', '127.0.0.1'].includes(address.hostname)) throw new Error('Analytics requires HTTPS.');
  if (!Number.isInteger(appId) || appId < 1 || appId > 2147483647) throw new Error('Invalid numerical app ID.');
  const key = `jenius-analytics-${appId}`;
  let allowed = false;
  let identity;
  let sessionId;
  let lastActivity = 0;
  let queue = [];
  let timer;
  let sending = false;
  let failures = 0;
  let controller;
  let consentVersion = 0;
  const getStorage = () => { try { return storage ?? globalThis.localStorage; } catch { return undefined; } };
  const safeUrl = value => {
    if (!value) return undefined;
    try {
      const url = new URL(value);
      if (!['http:', 'https:'].includes(url.protocol)) return undefined;
      url.pathname = url.pathname.split('/').map(part => {
        let decoded; try { decoded = decodeURIComponent(part); } catch { return ':redacted'; }
        return /[@=\d]/.test(decoded) || decoded.length > 48 ? ':redacted' : part;
      }).join('/');
      return (url.origin + url.pathname).slice(0, 512);
    } catch { return undefined; }
  };
  function schedule() {
    clearTimeout(timer);
    if (allowed && queue.length) timer = setTimeout(flush, flushMs * Math.min(8, 2 ** failures));
  }
  async function flush() {
    clearTimeout(timer);
    if (!allowed || sending || !queue.length || !transport) return;
    const batch = queue.splice(0, 20);
    const batchConsentVersion = consentVersion;
    sending = true;
    controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000);
    try {
      const response = await transport(`${address.origin}/api/collect/${appId}`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Analytics-Key': writeKey }, body: JSON.stringify({ consent: 'granted', events: batch }), signal: controller.signal, credentials: 'omit' });
      if (!response.ok && (response.status === 429 || response.status >= 500)) throw new Error('Retry');
      failures = 0;
    } catch {
      if (allowed && batchConsentVersion === consentVersion && failures < 3) { failures++; queue = [...batch, ...queue].slice(0, 100); }
      else failures = 0;
    } finally { clearTimeout(timeout); controller = undefined; sending = false; schedule(); }
  }
  function clear() {
    consentVersion++;
    allowed = false; queue = []; identity = undefined; sessionId = undefined; failures = 0;
    clearTimeout(timer); controller?.abort();
    try { getStorage()?.removeItem(key); } catch { /* No storage is required for consent to work. */ }
  }
  return {
    setConsent(value) {
      if (!value) { clear(); return; }
      if (allowed) return;
      allowed = true;
      try {
        const saved = JSON.parse(getStorage()?.getItem(key) ?? 'null');
        if (saved && /^[a-f0-9-]{36}$/i.test(saved.id) && saved.expires > clock() && saved.expires <= clock() + 366 * 86400000) identity = saved.id;
      } catch { /* Memory-only IDs when storage is unavailable. */ }
      identity ??= makeId();
      sessionId = makeId();
      try { getStorage()?.setItem(key, JSON.stringify({ id: identity, expires: clock() + 365 * 86400000 })); } catch { /* Continue in memory. */ }
    },
    track(name, fields = {}) {
      if (!allowed || !/^[a-z][a-z0-9_.-]{0,63}$/.test(name) || !['page','action','screen','api','error'].includes(fields.kind ?? 'action')) return;
      if (clock() - lastActivity > 30 * 60000) sessionId = makeId();
      lastActivity = clock();
      const event = { id: makeId(), name, kind: fields.kind ?? 'action', occurredAt: new Date(clock()).toISOString(), anonymousId: identity, sessionId, platform };
      // Explicit fields only: arbitrary payloads, text and bodies never enter the queue.
      for (const name of ['screen', 'feature']) if (typeof fields[name] === 'string') event[name] = fields[name].slice(0, 80);
      if (appVersion) event.appVersion = String(appVersion).slice(0, 32);
      if (fields.url) event.url = safeUrl(fields.url);
      if (fields.apiUrl) event.apiUrl = safeUrl(fields.apiUrl);
      if (['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS'].includes(fields.method)) event.method = fields.method;
      if (Number.isInteger(fields.status) && fields.status >= 100 && fields.status <= 599) event.status = fields.status;
      if (Number.isFinite(fields.durationMs) && fields.durationMs >= 0 && fields.durationMs <= 300000) event.durationMs = Math.round(fields.durationMs);
      queue.push(event);
      if (queue.length > 100) queue.shift();
      schedule();
      if (queue.length >= 20) void flush();
    },
    flush,
    destroy: clear
  };
}
