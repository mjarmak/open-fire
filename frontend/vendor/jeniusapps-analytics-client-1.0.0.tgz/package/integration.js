import { createAnalytics } from './analytics.js';
export { createAnalytics } from './analytics.js';

/** Optional integration: no setup UI, startup dependency, global fetch patch, or
 * traffic/storage before consent. Missing config and transport failures fail off. */
export function createOptionalLogger({ document, manager, slug, endpoint = 'https://analytics.jeniusapps.com', transport, storage, platform, flushMs } = {}) {
  let client;
  let pending;
  let controller;
  let generation = 0;
  let allowed = false;
  let disposed = false;
  let origins = [];
  let unsubscribe = () => {};
  const view = document?.defaultView;
  const fetch = transport ?? view?.fetch?.bind(view);
  let address;
  try { address = new URL(endpoint); } catch { /* Invalid optional config leaves logging off. */ }
  const enabled = Boolean(view && view.location.protocol === 'https:' && manager?.enabled && fetch && address?.protocol === 'https:' && /^[a-z][a-z0-9-]{1,47}$/.test(slug ?? ''));

  function reset() {
    allowed = false; generation++; controller?.abort(); pending = undefined;
    client?.destroy(); client = undefined; origins = [];
  }
  async function connect() {
    const version = generation;
    const abort = new AbortController();
    controller = abort;
    const timeout = setTimeout(() => abort.abort(), 3000);
    try {
      const response = await fetch(`${address.origin}/api/client-config/${slug}`, { signal: abort.signal, credentials: 'omit', cache: 'no-store' });
      if (!response.ok) return;
      const config = await response.json();
      if (disposed || !allowed || version !== generation) return;
      if (!Number.isInteger(config.appId) || config.appId < 1 || config.appId > 2147483647 || config.slug !== slug || !/^[a-f0-9]{48}$/.test(config.writeKey ?? '') || !Array.isArray(config.origins) || !config.origins.includes(view.location.origin)) return;
      origins = config.origins.filter(origin => { try { return new URL(origin).protocol === 'https:' && new URL(origin).origin === origin; } catch { return false; } });
      const userAgent = view.navigator.userAgent;
      client = createAnalytics({ endpoint: address.origin, appId: config.appId, writeKey: config.writeKey, storage, transport: fetch, flushMs, platform: platform ?? (userAgent.includes('OpenRemixerDesktop/') ? 'electron' : /Android/i.test(userAgent) ? 'android' : 'web') });
      client.setConsent(true);
    } catch { if (version === generation) { client?.destroy(); client = undefined; } /* Optional diagnostics must never break the application. */ }
    finally { clearTimeout(timeout); if (version === generation) { pending = undefined; controller = undefined; } }
  }
  const logger = {
    trackClick(name, url = view?.location.href) {
      if (!allowed || !client || !/^[a-z][a-z0-9_.-]{0,63}$/.test(name ?? '')) return;
      try { client.track(name, { kind: 'action', url, feature: 'button_click' }); } catch { /* Best effort. */ }
    },
    recordHttpError({ url, method, status } = {}) {
      if (!allowed || !client || !Number.isInteger(status) || status < 400 || status > 599) return;
      try {
        const target = new URL(url, view.location.href);
        if (target.origin === address.origin || !origins.includes(target.origin)) return;
        client.track('http_error', { kind: 'error', url: view.location.href, apiUrl: target.href, method, status });
      } catch { /* No bodies, headers, error messages or token-bearing query strings are recorded. */ }
    },
    async flush() { try { await client?.flush(); } catch { /* Best effort. */ } },
    destroy() { disposed = true; reset(); unsubscribe(); if (enabled) document.removeEventListener('click', onClick, true); }
  };
  function onClick(event) {
    if (!allowed || !client) return;
    // Only developer-authored names are read. Never infer labels from text,
    // aria-labels, form values, row contents, IDs or user-provided data.
    const element = event.composedPath().find(item => item?.hasAttribute?.('data-analytics-click'));
    if (!element || element.closest('[data-analytics-ignore], [inert]') || element.disabled) return;
    logger.trackClick(element.getAttribute('data-analytics-click'));
  }
  if (enabled) {
    document.addEventListener('click', onClick, true);
    unsubscribe = manager.subscribe(state => {
      if (!state.analytics) { reset(); return; }
      allowed = true;
      if (!disposed && !client && !pending) pending = connect();
    });
  }
  return logger;
}
