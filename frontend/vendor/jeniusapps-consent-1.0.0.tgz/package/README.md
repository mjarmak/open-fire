# @jeniusapps/consent

Single source for the Jenius Apps, Open Order dashboard and Open Fire consent
dialog, persistence and opt-in Google Analytics adapter. No Angular or other
runtime dependencies. Safe to import during server rendering; pass `enabled:
false` to controllers on the server and in isolated demos. Disabled managers
do not mount any dialog or settings controls. The UI mounts only in the browser.

The three choices are `denied` (essential storage only), `cookies` (permission
for optional preferences, analytics off), and `granted` (preferences and
analytics). There currently are no separate optional preference cookies in
these integrations. Consumers must check `getState().preferences` before adding
optional preference storage. Authentication/session storage is separate.

Each app has a versioned, host-only cookie and localStorage record with a
one-year expiry. Old shared denials are respected; old grants prompt again.
Cookies and localStorage are consent storage, not analytics identifiers. A
Cookie Settings button allows changes, including withdrawal in the same page.
The adapter applies Google's opt-out flag before clearing its cookies/queued
events. No analytics script is loaded before an explicit analytics grant.

Google Analytics remains the provider; this package does not add the proposed
custom event/API log service. Our page-view events omit query strings,
fragments, numeric/email/long path identifiers and dynamic page titles.
Review route naming before adding analytics to another app: arbitrary names in
URL paths are not reliably classifiable. GA property-side enhanced measurement
settings remain an administrative setting and should be reviewed separately.
No API instrumentation, payload logging or session replay is included.

```ts
import { createConsentManager, createGoogleAnalytics, mountConsentDialog } from '@jeniusapps/consent';
const manager = createConsentManager({ document, appId: 'my-app', appName: 'My App' });
const analytics = createGoogleAnalytics({ document, manager, measurementId: 'G-EXAMPLE' });
const unmount = mountConsentDialog(hostElement, manager);
// Call after a committed route change; permission is checked on every call.
analytics.trackPageView();
// On teardown: unmount(); analytics.destroy(); manager.destroy();
```

## Release and consume

Source lives here, in `jeniusapps/packages/consent`. Run `npm run test:consent`,
bump this package version for changes, then `npm run package:consent`. The
resulting immutable npm release archive is distributed in each app's `vendor/`
directory and pinned in its package.json and lockfile. These archives are
vendored dependency releases, not independently edited component copies. Each
checkout and Docker build works without a sibling checkout, registry login or
runtime CDN. Never edit the archive in a consumer. Updating the source requires
repacking, updating all consumers and rebuilding them; it is not a live CDN.

Verified Google configuration references:
- https://developers.google.com/tag-platform/security/guides/privacy
- https://developers.google.com/analytics/devguides/collection/ga4/reference/config
