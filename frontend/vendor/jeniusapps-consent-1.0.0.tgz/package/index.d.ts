export type ConsentChoice = 'granted' | 'cookies' | 'denied';
declare global {
  interface Window {
    dataLayer: unknown[];
    gtag?: (...args: unknown[]) => void;
  }
}
export interface ConsentState {
  readonly choice: ConsentChoice | null;
  readonly preferences: boolean;
  readonly analytics: boolean;
  readonly showPrompt: boolean;
  readonly persisted: boolean;
}
export interface ConsentManager {
  readonly enabled: boolean;
  readonly appId: string;
  readonly appName: string;
  readonly key: string;
  getState(): ConsentState;
  choose(choice: ConsentChoice): void;
  open(): void;
  close(): void;
  subscribe(listener: (state: ConsentState) => void): () => void;
  refresh(): void;
  destroy(): void;
}
export interface GoogleAnalyticsAdapter {
  trackPageView(): void;
  destroy(): void;
}
export function createConsentManager(options: { document: Document; appId: string; appName: string; enabled?: boolean }): ConsentManager;
export function createGoogleAnalytics(options: { document: Document; manager: ConsentManager; measurementId: string; enabled?: boolean }): GoogleAnalyticsAdapter;
export function mountConsentDialog(host: HTMLElement, manager: ConsentManager): () => void;
export function sanitizePageUrl(value: string): string | null;
