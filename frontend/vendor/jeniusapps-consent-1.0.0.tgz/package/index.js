const VERSION = 1;
const MAX_AGE = 365 * 24 * 60 * 60;
const CHOICES = new Set(['granted', 'cookies', 'denied']);

/** Host-only, per-app consent. No network access and no storage until a choice. */
export function createConsentManager({ document, appId, appName, enabled = true }) {
  if (!/^[a-z][a-z0-9-]{0,63}$/.test(appId)) throw new Error('Use a lowercase app ID.');
  const view = enabled ? document?.defaultView : null;
  const key = `jenius-consent-v${VERSION}-${appId}`;
  const listeners = new Set();
  let record = null;
  let showing = false;
  let persisted = true;
  let destroyed = false;

  function parse(value) {
    try {
      const candidate = JSON.parse(value);
      return candidate?.version === VERSION && CHOICES.has(candidate.choice)
        && Number.isFinite(candidate.updatedAt) && candidate.updatedAt <= Date.now()
        && Date.now() - candidate.updatedAt < MAX_AGE * 1000 ? candidate : null;
    } catch { return null; }
  }
  function cookieValue() {
    try {
      const entry = document.cookie.split(';').map(part => part.trim()).find(part => part.startsWith(`${key}=`));
      return entry ? parse(decodeURIComponent(entry.slice(key.length + 1))) : null;
    } catch { return null; }
  }
  function read() {
    const cookie = cookieValue();
    let local = null;
    try { local = parse(view.localStorage.getItem(key)); } catch { /* Cookie fallback. */ }
    if (!cookie) return local;
    if (!local) return cookie;
    if (cookie.updatedAt !== local.updatedAt) return cookie.updatedAt > local.updatedAt ? cookie : local;
    // If one persistence method rejected a write, an equal-time refusal wins.
    const rank = { denied: 0, cookies: 1, granted: 2 };
    return rank[cookie.choice] <= rank[local.choice] ? cookie : local;
  }
  function state() {
    return Object.freeze({
      choice: record?.choice ?? null,
      preferences: record?.choice === 'granted' || record?.choice === 'cookies',
      analytics: record?.choice === 'granted',
      showPrompt: showing,
      persisted
    });
  }
  function save() {
    const value = JSON.stringify(record);
    let savedLocal = false;
    try { view.localStorage.setItem(key, value); savedLocal = true; } catch { /* Cookie fallback below. */ }
    try {
      const secure = view.location.protocol === 'https:' ? '; Secure' : '';
      document.cookie = `${key}=${encodeURIComponent(value)}; Max-Age=${MAX_AGE}; Path=/; SameSite=Lax${secure}`;
    } catch { /* In-memory consent remains usable when storage is blocked. */ }
    persisted = savedLocal || cookieValue()?.choice === record.choice;
  }
  function notify() { for (const listener of listeners) listener(state()); }
  function refresh() {
    if (!view || destroyed || !persisted) return;
    const next = read();
    if (JSON.stringify(next) === JSON.stringify(record)) return;
    record = next;
    showing = !record;
    notify();
  }
  if (view) {
    record = read();
    // Old shared grants do not cover the new per-app, three-choice notice.
    // A prior refusal is respected without granting any additional permission.
    if (!record) {
      let legacy;
      try {
        legacy = document.cookie.split(';').map(part => part.trim())
          .find(part => part.startsWith('jeniusapps-analytics-consent='))?.split('=')[1]
          ?? view.localStorage.getItem('jeniusapps-analytics-consent');
      } catch { /* Storage is optional; the prompt still works in memory. */ }
      if (legacy === 'denied') {
        record = { version: VERSION, choice: 'denied', updatedAt: Date.now() };
        save();
      }
    }
    showing = !record;
    view.addEventListener('storage', refresh);
    view.addEventListener('focus', refresh);
    view.addEventListener('pageshow', refresh);
  }
  return {
    appId, appName, key, enabled: Boolean(view),
    getState: state,
    choose(choice) {
      if (!CHOICES.has(choice)) throw new Error('Unknown consent choice.');
      if (!view || destroyed) return;
      record = { version: VERSION, choice, updatedAt: Date.now() };
      showing = false;
      save();
      notify();
    },
    open() { if (view && !destroyed) { showing = true; notify(); } },
    close() { if (record) { showing = false; notify(); } },
    subscribe(listener) { listeners.add(listener); listener(state()); return () => listeners.delete(listener); },
    refresh,
    destroy() {
      destroyed = true;
      view?.removeEventListener('storage', refresh);
      view?.removeEventListener('focus', refresh);
      view?.removeEventListener('pageshow', refresh);
      listeners.clear();
    }
  };
}

/** Removes query/fragment data and common identifiers before our page-view events. */
export function sanitizePageUrl(value) {
  try {
    const url = new URL(value);
    if (!['http:', 'https:'].includes(url.protocol)) return null;
    const pathname = url.pathname.split('/').map(segment => {
      let decoded;
      try { decoded = decodeURIComponent(segment); } catch { return ':redacted'; }
      return /@|\d|[=]/.test(decoded) || decoded.length > 48 ? ':redacted' : segment;
    }).join('/');
    return `${url.origin}${pathname}`;
  } catch { return null; }
}

/** A basic opt-in Google tag adapter. Routing remains the consuming app's job. */
export function createGoogleAnalytics({ document, manager, measurementId, enabled = true }) {
  if (!/^G-[A-Z0-9]+$/.test(measurementId)) throw new Error('Invalid Google Analytics measurement ID.');
  const view = enabled ? document?.defaultView : null;
  const scriptId = 'jeniusapps-google-analytics';
  const disableKey = `ga-disable-${measurementId}`;
  const prefix = `jenius_${manager.appId.replaceAll('-', '_')}`;
  let initialized = false;
  let lastPage = '';
  function clearCookies() {
    const hostname = view.location.hostname;
    const domains = ['', ...hostname.split('.').map((_, index, parts) => `; Domain=${parts.slice(index).join('.')}`)];
    const paths = ['/', ...view.location.pathname.split('/').map((_, index, parts) => parts.slice(0, index + 1).join('/') || '/')];
    for (const part of document.cookie.split(';')) {
      const name = part.trim().split('=')[0];
      // Also retire the unprefixed cookies left by the previous integration.
      if (name !== '_ga' && !name.startsWith('_ga_') && !name.startsWith(`${prefix}_`)) continue;
      for (const domain of domains) for (const path of paths) {
        document.cookie = `${name}=; Max-Age=0; Path=${path}${domain}; SameSite=Lax`;
      }
    }
  }
  function update(state) {
    if (!view) return;
    view[disableKey] = !state.analytics;
    if (!state.analytics) {
      if (initialized) {
        // The opt-out flag is applied before any tag code can run again.
        view.dataLayer = [];
        document.getElementById(scriptId)?.remove();
        initialized = false;
      }
      lastPage = '';
      clearCookies();
      return;
    }
    if (initialized) return;
    initialized = true;
    view.dataLayer = view.dataLayer ?? [];
    view.gtag = (...args) => { if (manager.getState().analytics) view.dataLayer.push(args); };
    view.gtag('consent', 'default', {
      analytics_storage: 'granted', ad_storage: 'denied', ad_user_data: 'denied', ad_personalization: 'denied'
    });
    view.gtag('js', new Date());
    view.gtag('config', measurementId, {
      send_page_view: false, cookie_domain: 'none', cookie_prefix: prefix,
      cookie_expires: MAX_AGE, allow_google_signals: false, allow_ad_personalization_signals: false,
      page_location: sanitizePageUrl(view.location.href) ?? view.location.origin,
      page_referrer: '', page_title: manager.appName
    });
    if (!document.getElementById(scriptId)) {
      const script = document.createElement('script');
      script.id = scriptId;
      script.async = true;
      script.src = `https://www.googletagmanager.com/gtag/js?id=${measurementId}`;
      document.head.appendChild(script);
    }
  }
  const unsubscribe = manager.subscribe(update);
  return {
    trackPageView() {
      manager.refresh();
      if (!view || !initialized || !manager.getState().analytics) return;
      const location = sanitizePageUrl(view.location.href);
      if (!location || location === lastPage || !view.gtag) return;
      lastPage = location;
      view.gtag('event', 'page_view', {
        page_title: manager.appName, page_location: location,
        page_path: new URL(location).pathname, page_referrer: ''
      });
    },
    destroy() { unsubscribe(); if (view) view[disableKey] = true; }
  };
}

const STYLES = `
:host{display:block;color-scheme:dark;font:400 14px/1.55 Arial,Helvetica,sans-serif}
*{box-sizing:border-box}[hidden]{display:none!important}
.consent-card{position:fixed;z-index:10000;right:22px;bottom:22px;width:min(650px,calc(100vw - 44px));max-height:calc(100dvh - 44px);overflow:auto;padding:26px;border:1px solid #343d57;border-radius:22px;background:#0e1222;color:#f5f7ff;box-shadow:0 16px 44px #00000035}
h2{margin:0;font-size:22px;line-height:1.3;letter-spacing:-.5px}p{margin:18px 0 0}.secondary{color:#b6bdd0;font-size:13px;margin-top:12px}
details{margin-top:10px}summary{padding:12px 0;min-height:44px;color:#f0a098;cursor:pointer}dl{margin:0 0 12px}dl>div{display:grid;grid-template-columns:112px minmax(0,1fr);gap:12px;padding:9px 0}dt{font-weight:700}dd{margin:0;color:#b6bdd0;overflow-wrap:anywhere}
.actions{display:grid;grid-template-columns:1fr 1fr 1.6fr;gap:10px;margin-top:12px}
button{appearance:none;min-height:48px;padding:10px 12px;border:1px solid #f0a098;border-radius:13px;background:#0e1222;color:#f5f7ff;font:700 13px/1.35 Arial,Helvetica,sans-serif;white-space:normal;cursor:pointer}
button.primary{background:#f0a098;color:#151a2d}button:hover{filter:brightness(1.12)}button:focus-visible,summary:focus-visible{outline:3px solid #fff;outline-offset:3px}
.settings{position:fixed;z-index:9999;left:12px;bottom:12px;min-height:44px;padding:8px 12px;font-size:12px;box-shadow:0 4px 16px #0004}
.keep{margin-top:12px;min-height:44px;border-color:#343d57}.notice{color:#b6bdd0;font-size:13px}
@media(max-width:520px){.consent-card{right:12px;bottom:12px;width:calc(100vw - 24px);max-height:calc(100dvh - 24px);padding:20px 16px}h2{font-size:21px}.actions{grid-template-columns:1fr}dl>div{grid-template-columns:1fr;gap:3px}}
@media(prefers-reduced-motion:no-preference){.consent-card{animation:consent-enter .16s ease-out}@keyframes consent-enter{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}}
`;

/** One shared UI, rendered in Shadow DOM so app styles cannot alter consent controls. */
export function mountConsentDialog(host, manager) {
  const document = host.ownerDocument;
  if (!document.defaultView || !manager.enabled) return () => {};
  const root = host.shadowRoot ?? host.attachShadow({ mode: 'open' });
  root.innerHTML = `<style>${STYLES}</style>
    <aside class="consent-card" role="dialog" aria-labelledby="consent-title" aria-describedby="consent-copy" hidden>
      <h2 id="consent-title">Help us make it better</h2>
      <p id="consent-copy">Cookies can remember your preferences. Optional analytics help us make <span class="app-name"></span> easier to use.</p>
      <p class="secondary">It’s your choice. You can change it anytime.</p>
      <details><summary>What’s shared?</summary><dl>
        <div><dt>Your choices</dt><dd>Only Cookies allows optional preference storage, with analytics off. Allow Cookies &amp; Analytics also enables Google Analytics. No thanks keeps only essential storage, including your choice. These apps currently add no separate optional preference cookies.</dd></div>
        <div><dt>Analytics</dt><dd>Google Analytics measures visits, navigation, browser/device information and repeat visits using a cookie identifier. Advertising features stay disabled.</dd></div>
        <div><dt>Page URLs</dt><dd>Our page-view events exclude URL query strings, fragments and common identifiers. Page titles use the app name.</dd></div>
        <div><dt>No payload logs</dt><dd>This integration does not log API URLs, request or response bodies, file contents, or session recordings.</dd></div>
        <div><dt>Your choice</dt><dd>Saved for up to one year for <span class="scope-name"></span> only. Old shared acceptance does not enable analytics here. Essential sign-in storage remains available.</dd></div>
      </dl></details>
      <div class="actions"><button type="button" data-choice="denied">No thanks</button><button type="button" class="primary" data-choice="cookies">Only Cookies</button><button type="button" class="primary" data-choice="granted">Allow Cookies &amp; Analytics</button></div>
      <button type="button" class="keep" hidden>Keep Current Choice</button>
    </aside>
    <button type="button" class="settings" hidden>Cookie Settings</button>
    <p class="notice" role="status" hidden>Your choice is saved for this session only because browser storage is unavailable.</p>`;
  root.querySelector('.app-name').textContent = manager.appName;
  root.querySelector('.scope-name').textContent = manager.appName;
  const panel = root.querySelector('.consent-card');
  const settings = root.querySelector('.settings');
  const keep = root.querySelector('.keep');
  let wasOpen = false;
  let returnFocus = null;
  const unsubscribe = manager.subscribe(state => {
    const focusInside = panel.contains(root.activeElement);
    panel.hidden = !state.showPrompt;
    settings.hidden = state.showPrompt;
    keep.hidden = state.choice === null;
    root.querySelector('.notice').hidden = state.persisted || state.showPrompt;
    if (wasOpen && !state.showPrompt && focusInside) (returnFocus ?? settings).focus();
    wasOpen = state.showPrompt;
  });
  const onClick = event => {
    const target = event.target.closest('button');
    if (!target) return;
    if (target.dataset.choice) manager.choose(target.dataset.choice);
    else if (target === settings) {
      returnFocus = settings;
      manager.open();
      root.querySelector('[data-choice]').focus();
    } else if (target === keep) manager.close();
  };
  root.addEventListener('click', onClick);
  const onKey = event => { if (event.key === 'Escape' && manager.getState().choice !== null) manager.close(); };
  root.addEventListener('keydown', onKey);
  return () => { unsubscribe(); root.removeEventListener('click', onClick); root.removeEventListener('keydown', onKey); root.replaceChildren(); };
}
